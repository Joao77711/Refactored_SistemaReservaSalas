package com.example.sistema;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SalaRepository extends JpaRepository<Sala, Long> {}
